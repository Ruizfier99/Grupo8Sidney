package com.ruizcrack.sidneyaplication

data class UbicacionPOI(
    val nombrePoi:String,
    val nombreCategoria:String,
    val imagen:String,
    val descripcion: String,
    val puntuacion: String
                        )