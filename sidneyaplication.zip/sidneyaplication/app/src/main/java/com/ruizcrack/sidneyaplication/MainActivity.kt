package com.ruizcrack.sidneyaplication
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {
    var puntosInteres:List<UbicacionPOI> = listOf(
        UbicacionPOI("Opera de Sydney",  "Arte y Ocio",  "https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Sydney_Opera_House_Sails.jpg/250px-Sydney_Opera_House_Sails.jpg",  "la opera de Sydney", "5 Estrellas" ),
        UbicacionPOI("Opera de Sydney", "Arte y Ocio",  "https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Sydney_Opera_House_Sails.jpg/250px-Sydney_Opera_House_Sails.jpg",  "la opera de Sydney", "5 Estrellas" )
    )
    ///private fun generateUbicaciones() {
    // val ubicacionesString = readContactJsonFile()

    //try {

    ////for (i in 0 until ubicacionesJson.length()) {
     // val ubicacionJson = ubicacionesJson.getJSONObject(i)
     //val ubicacion = UbicacionPOI(
      // ubicacionJson.getString("NombrePoi"),
     //ubicacionJson.getString("NombreCategoria"),
    //ubicacionJson.getString("Imagen"),
    //ubicacionJson.getString("descripcion"),
    //ubicacionJson.getString("puntuacion")
    //)
     //puntosInteres.add(ubicacion)

    //}

    //} catch (e: JSONException) {
     //e.printStackTrace()
    //}
     //}
    //private fun readContactJsonFile(): String?{
      //var ubicacionesString: String?= null
    //try {
    //val inputStream = assets.open("infoPuntosPoi.json")
    //val size = inputStream.available()
    //val buffer = ByteArray(size)
    //inputStream.read(buffer)
    //inputStream.close()
    //ubicacionesString = String(buffer)
    //} catch(e:IOException){
      //e.printStackTrace()


    //}
    //return ubicacionesString
     //}


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        initRecycler()
    }


    fun initRecycler(){
        findViewById<RecyclerView>(R.id.rvUbicacionesSidney).layoutManager= LinearLayoutManager(this)
        val adapter = UbicacionAdapter(puntosInteres)
        findViewById<RecyclerView>(R.id.rvUbicacionesSidney).adapter= adapter

    }
}